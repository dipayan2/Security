package main

import (
	"fmt"
	"math/rand"
	"time"
	"strings"
	"crypto/md5"
)

var letterRunes = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
var injections = []string{
	"'<",
}

func RandStringRunes(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letterRunes[rand.Intn(len(letterRunes))]
	}
	return string(b)
}

func TestString(val [16]byte, needle string) bool {
	for num:=1; num<10; num++ {
		if strings.Contains(fmt.Sprintf("%s",val), fmt.Sprintf("%s%d#", needle, num)) {
			return true
		}
	}
	return false
}

func main() {
	rand.Seed(time.Now().UnixNano())
	for count := 0; ; count++ {
		val := RandStringRunes(25)
		hash := md5.Sum([]byte(val))
		result := false
		for _,inj := range injections {
			result = result || TestString(hash, inj)
		}
		if count%1000000 == 0 {
			fmt.Println(val)
		}
		if result {
			fmt.Println("FOUND:", val)
			return
		}
	}
}
